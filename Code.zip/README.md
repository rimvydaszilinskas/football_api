# Running

```
docker-compose up
```
